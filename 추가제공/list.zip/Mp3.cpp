#include "Mp3.h"
#include <iostream.h>
Mp3::Mp3(char n_maker[],char n_model[], char n_file[]){
	maker = n_maker;
	model = n_model;
	file = n_file;
}
Mp3::Mp3(){

}
void Mp3::SetMaker(char n_maker[]){
	maker = n_maker;
}
void Mp3::SetModel(char n_model[]){
	model = n_model;
}
void Mp3::SetFile(char n_file[]){
	file = n_file;
}
char *Mp3::GetMaker(){
	return maker;
}
char *Mp3::GetModel(){
	return model;
}
char *Mp3::GetFile(){
	return file;
}
void Mp3::playFile(){
	cout << file << " �� ���" << endl;
}
void Mp3::stopFile(){
	cout << file << " �� ��� ����" << endl;
}
	