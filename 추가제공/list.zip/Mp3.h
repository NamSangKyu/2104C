class Mp3{
private:
	//������
	char *maker;
	//�𵨸�
	char *model;
	//���
	char *file;
public:
	//������
	Mp3(char n_maker[],char model[], char file[]);
	Mp3();
	void SetMaker(char n_maker[]);
	void SetModel(char n_model[]);
	void SetFile(char n_file[]);
	char *GetMaker();
	char *GetModel();
	char *GetFile();
	
	void playFile();
	void stopFile();
	
};
class Irever : public Mp3{
	
};